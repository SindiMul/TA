<link
  rel="stylesheet"
  href="{{ url('frontend/libraries/bootstrap/css/bootstrap.css') }}"
/>
<link
  href="https://fonts.googleapis.com/css?family=Assistant:200,300,400,600,700,800|Playfair+Display:400,400i,700,700i,900,900i&display=swap"
  rel="stylesheet"
/>
<link rel="stylesheet" href="{{ url('frontend/styles/main.css') }}" />
<link rel="stylesheet" href="{{ url('frontend/fontawesome/css/all.min.css') }}">