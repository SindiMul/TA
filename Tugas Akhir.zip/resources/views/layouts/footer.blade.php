<footer>
    <hr>
    <div class="container">
        <div class="row">
            <div class="col text-center">
                Copyright @2020 Wahidev Academy
            </div>
        </div>
    </div>
</footer>