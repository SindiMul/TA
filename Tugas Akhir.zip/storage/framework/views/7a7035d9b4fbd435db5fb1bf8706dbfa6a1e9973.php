<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <?php echo $__env->yieldPushContent('prepend-style'); ?>
    <?php echo $__env->make('includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('addon-style'); ?>
    
  </head>
  
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>


</head>
<body>
    <div id="app">
        
        <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('navbar', [])->dom;
} elseif ($_instance->childHasBeenRendered('un4vCKz')) {
    $componentId = $_instance->getRenderedChildComponentId('un4vCKz');
    $componentTag = $_instance->getRenderedChildComponentTagName('un4vCKz');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('un4vCKz');
} else {
    $response = \Livewire\Livewire::mount('navbar', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('un4vCKz', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

        <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    

        <?php echo $__env->yieldPushContent('prepend-script'); ?>
        <?php echo $__env->make('includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldPushContent('addon-script'); ?>
        </main>
        
        
    </div>
</body>
</html>
<?php /**PATH F:\Tugas Akhir\resources\views/layouts/app.blade.php ENDPATH**/ ?>