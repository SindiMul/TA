<?php $__env->startSection('title', 'Detail paket'); ?>

<?php $__env->startSection('content'); ?>
<main>
      <section class="section-details-header"></section>
      <section class="section-details-content">
        <div class="container">
          <div class="row">
            <div class="col p-0">
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item" aria-current="page">
                    Paket Outbond Event
                  </li>
                  <li class="breadcrumb-item active" aria-current="page">
                    Details
                  </li>
                </ol>
              </nav>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-8 pl-lg-0">
              <div class="card card-details">
                <h1><?php echo e($item->title); ?></h1>
                <p>
                <?php echo e($item->location); ?>

                </p>
                <?php if($item->galleries->count() > 0): ?>
                <div class="gallery">
                  <div class="xzoom-container">
                    <img
                      class="xzoom"
                      id="xzoom-default"
                      src="<?php echo e(Storage::url($item->galleries->first()->image)); ?>"
                      xoriginal="<?php echo e(Storage::url($item->galleries->first()->image)); ?>"
                    />
                    <div class="xzoom-thumbs">
                    <?php $__currentLoopData = $item->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <a href="<?php echo e(Storage::url($gallery->image)); ?>"
                        ><img
                          class="xzoom-gallery"
                          width="128"
                          src="<?php echo e(Storage::url($gallery->image)); ?>"
                          xpreview="<?php echo e(Storage::url($gallery->image)); ?>"
                      /></a>
                     
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  </div>
                  <?php endif; ?>
                  <h2>Tentang Wisata</h2>
                  <p>
                  <?php echo $item->about; ?>

                  </p>
                  <div class="features row pt-3">
                    <div class="col-md-4">
                      <img
                        src="<?php echo e(url('frontend/images/ic_event.png')); ?>"
                        alt=""
                        class="features-image"
                      />
                      <div class="description">
                        <h3>Featured Ticket</h3>
                        <p><?php echo e($item->featured_event); ?></p>
                      </div>
                    </div>
                    
                    <div class="col-md-4 border-left">
                      <img
                        src="<?php echo e(url('frontend/images/ic_foods.png')); ?>"
                        alt=""
                        class="features-image"
                      />
                      <div class="description">
                        <h3>Foods</h3>
                        <p><?php echo e($item->foods); ?></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4">
            <form action="<?php echo e(route('checkout_process', $item->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
              <div class="card card-details card-right">
              <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
              
                <h2>paket Informations</h2>
                <table class="trip-informations">
                  
                  <tr>
                    <th width="50%">Duration</th>
                    <td width="50%" class="text-right"><?php echo e($item->duration); ?></td>
                  </tr>
                  <tr>
                    <th width="50%">Type</th>
                    <td width="50%" class="text-right"><?php echo e($item->type); ?></td>
                  </tr>
                  <tr>
                    <th width="50%">Price</th>
                    <td width="50%" class="text-right">Rp <?php echo e(number_format($item->price)); ?></td>
                  </tr>
                  <tr>
                    <th colspan="2">departure date</th>
                  </tr>
                  <tr>
                    <th colspan="2">
                    <input
                    type="date"
                    name="departure_date"
                    class="form-control datepicker "
                    id="departure_date"
                    placeholder="departure date"
                    required/>
                  
                    </th>
                  </tr>
                </table>
              </div>
              <div class="join-container">
              <?php if(auth()->guard()->check()): ?>
              
                  <button class="btn btn-block btn-join-now mt-3 py-2" type="submit">
                      Join Now
                  </button>
              </form>
              <?php endif; ?>
              <?php if(auth()->guard()->guest()): ?>
                  <a href="<?php echo e(route('login')); ?>" class="btn btn-block btn-join-now mt-3 py-2">
                      Login or Register to Join
                  </a>
              <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
    <?php $__env->stopSection(); ?>

<?php $__env->startPush('prepend-style'); ?>
    <link rel="stylesheet" href="<?php echo e(url('frontend/libraries/xzoom/xzoom.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <script src="<?php echo e(url('frontend/libraries/xzoom/xzoom.min.js')); ?>"></script>
    <script>
      $(document).ready(function() {
        $('.xzoom, .xzoom-gallery').xzoom({
          zoomWidth: 500,
          title: false,
          tint: '#333',
          Xoffset: 15
        });
      });
    </script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('prepend-style'); ?>
  <link rel="stylesheet" href="<?php echo e(url('frontend/libraries/gijgo/css/gijgo.min.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
  <script src="<?php echo e(url('frontend/libraries/gijgo/js/gijgo.min.js')); ?>"></script>
  <script>
    $(document).ready(function() {
      $('.datepicker').datepicker({
        format: 'yyyy-mm-dd',
        uiLibrary: 'bootstrap4',
        icons: {
          rightIcon: '<img src="<?php echo e(url('frontend/images/ic_doe.png')); ?>" />'
        }
      });
    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Tugas Akhir\resources\views/pages/detail.blade.php ENDPATH**/ ?>