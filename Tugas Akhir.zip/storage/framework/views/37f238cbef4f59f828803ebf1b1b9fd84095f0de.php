<?php $__env->startSection('title'); ?>
DIGARUT
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
       <!-- header -->
       <header class="text-center">
            <H1>Explore The Beauty of Garut <br>
                 With Outbound Events</H1>
                 <P>You will feel your vacation <br>
                    more attractive with various kinds of events
                </P>
        </header>

        <!-- paket -->
       
                   
                    
                 
                </div>

            </div>

        </section>


         <!-- product -->
         <section class="section-event" id="eventpopular">
            <div class="container">
                <div class="row">
                    <div class="col mt-5 mb-5 section-event-heading">
                        <h2> <strong>product Digarut </strong> 
                            <a href="<?php echo e(route('products')); ?>" class="btn btn-get-started ml-auto ">
                                See All
                              </a>
                        </h2>

                    </div>
                </div>
                <div class="row">
             <div class="produk-items">
                 <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="item">
                      <img src="<?php echo e(Storage::url($product->productgalery->first()->image)); ?>" />
                      <div class="inner">
                          <div class="info">
                               <h5><?php echo e($product->title); ?></h5>
                               <p><?php echo e($product->location); ?></p>
                               <div class="event-button mt-auto">
                             <a href="<?php echo e(route('products.detail', $product->slug)); ?>"  class="btn btn-event-details px-4">
                                view detail
                             </a>   
                            </div>
                          </div>
                      </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
             </div>
         </div>
            </div>
        </section>
  

       

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Tugas Akhir\resources\views/livewire/home.blade.php ENDPATH**/ ?>