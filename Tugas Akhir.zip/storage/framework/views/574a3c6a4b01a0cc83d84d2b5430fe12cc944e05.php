<main>
  <section class="section-details-header"></section>
  <section class="section-details-content">
    <div class="container">
      <div class="row">
        <div class="row mt-4 mb-2">
          <div class="col">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-dark">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Cart</li>
              </ol>
            </nav>
          </div>
        </div>
      </div> 
      <div class="row"> 
        <div class="col-lg-8 pl-lg-0">
          <div class="card card-details">
          <?php if(session()->has('message')): ?>
                <div class="alert alert-danger"> <?php echo e(session('message')); ?></div>
                    <?php endif; ?>
            <h1>Your Cart?</h1>
            
            <div class="attendee">
                <table class="table table-responsive-sm text-center">
                        <thead>
                        <tr>
                            <td>no</td>
                            <td>Name</td>
                            <td>jumlah</td>
                            <td>price</td>
                            <td>total</td>
                            <td>departure Datae</td>
                            <td></td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $no = 1 ?>
                            <?php $__empty_1 = true; $__currentLoopData = $pesanan_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                            <td class="align-middle"><?php echo e($pesanan->aa); ?></td>
                            <td class="align-middle"><?php echo e($pesanan_detail->product->title); ?></td>
                            <td class="align-middle"><?php echo e($pesanan_detail->jumlah_pesanan); ?></td>
                            <td class="align-middle">Rp. <?php echo e(number_format($pesanan_detail->product->price)); ?></td>
                            <td class="align-middle">Rp. <?php echo e(number_format($pesanan_detail->total_harga)); ?></td>
                            <td class="align-middle"><?php echo e($pesanan_detail->date); ?></td>
                            <td><img src="<?php echo e(url('frontend/images/ic_remove.png')); ?>" wire:click="destroy(<?php echo e($pesanan_detail->id); ?>)" alt="" />
                            </td>
                            </tr>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="7">Data Kosong</td> </tr>   
                            <?php endif; ?>
                        </tbody>
                </table>
            </div>
            
          </div>
        </div>
        <?php if(!empty($pesanan)): ?>
        <div class="col-lg-4">
          <div class="card card-details card-right">
            <h2>Checkout Informations</h2>
            
            <table class="trip-informations">
            
              <tr>
                <th width="50%">Total price </th>
                <td width="50%" class="text-right text-total">
                  <span class="text-blue">Rp. <?php echo e(number_format($pesanan->total_harga)); ?> </span
                  >
                </td>
              </tr>
            </table>

            <hr />
            <h2>Payment Instructions</h2>
            <p class="payment-instructions">
              Please complete your payment before to continue the 
              trip or event
            </p>
           
          </div>
          <div class="join-container">
                         <a href="<?php echo e(route('transaction')); ?>" class="btn btn-block btn-join-now mt-3 py-2">
                            Check Out
                         </a>
                        </div>
                        <?php endif; ?>
          
          
        </div>
      </div>
    </div>
  </section>
</main><?php /**PATH D:\Tugas Akhir\resources\views/livewire/keranjang.blade.php ENDPATH**/ ?>