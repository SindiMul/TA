<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

      <!-- Page Heading -->
      <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Detail Transaksi <?php echo e($item->user->name); ?></h1>
      </div>

      <!-- Content Row -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="card shadow">
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <th>ID</th>
                        <td><?php echo e($item->id); ?></td>
                    </tr>
                    <tr>
                        <th>Order Code </th>
                        <td><?php echo e($item->kode_pemesanan); ?></td>
                    </tr>
                    <tr>
                        <th>Pembeli</th>
                        <td><?php echo e($item->user->name); ?></td>
                    </tr>
                    <tr>
                        <th>Status Transaksi</th>
                        <td><?php echo e($item->status); ?></td>
                    </tr>
                    <tr>
                        <th>Pembelian</th>
                        <td>
                            <table class="table table-bordered">
                                <tr>
                                    <th>ID</th>
                                    <th>Nama Item</th>
                                    <th>Departure Date</th>
                                    <th>Price</th>
                                    <th>Total Order </th>
                                    <th>Total Price</th>
                                </tr>
                                <?php $__currentLoopData = $item->pesanan_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($detail->id); ?></td>
                                        <td><?php echo e($detail->product->title); ?></td>
                                        <td><?php echo e($detail->date); ?></td>
                                        <td><?php echo e($detail->product->price); ?></td>
                                        <td><?php echo e($detail->jumlah_pesanan); ?></td>
                                        <td><?php echo e(number_format($detail->total_harga)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </td>
                    </tr>
                    <tr>
                      <th>Total Price</th>
                      <th >Rp <?php echo e(number_format($item->total_harga)); ?></th>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Tugas Akhir\resources\views/pages/admin/transaction2/detail.blade.php ENDPATH**/ ?>