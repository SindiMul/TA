<div class="container-fluid">
    <div
      class="row border-top justify-content-center align-items-center pt-4"
    >
      <div class="col-auto text-gray-500 font-weight-light">
        2021 Copyright Digarut • All rights reserved • Made in Garut
      </div>
    </div>
  </div>
</footer><?php /**PATH E:\Tugas Akhir\resources\views/includes/footer.blade.php ENDPATH**/ ?>