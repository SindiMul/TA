<div class="container">
      <nav class="row navbar navbar-expand-lg navbar-light bg-white">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
          <img src="<?php echo e(url('frontend/images/logo.png')); ?>" alt="" />
        </a>
        <button
          class="navbar-toggler navbar-toggler-right"
          type="button"
          data-toggle="collapse"
          data-target="#navb"
        >
          <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Menu -->
        <div class="collapse navbar-collapse" id="navb">
          <ul class="navbar-nav ml-auto mr-3">
              <li class="nav-item mx-md-2">
                  <a href="<?php echo e(route('home')); ?>" class="nav-link active">Home</a>
              </li>
              <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            List category
                        </a>
                        
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item"
                                href="<?php echo e(route('products.category', $category->id)); ?>"><?php echo e($category->nama); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('products')); ?>">All Item</a>
                        </div>
              </li>
              <li class="nav-item mx-md-2">
                    <?php if(auth()->guard()->check()): ?>
                  <a href="<?php echo e(url('history')); ?>" class="nav-link">history</a>
                  <?php endif; ?>
              </li>
              <?php if(auth()->guard()->guest()): ?>
                  <a href="<?php echo e(url('login')); ?>" class="nav-link">history</a>
                  <?php endif; ?>
              <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('keranjang')); ?>">
                            Cart <i class="fas fa-shopping-bag"></i>
                            <?php if($jumlah_pesanan !==0): ?>
                            <span class="badge badge-danger"><?php echo e($jumlah_pesanan); ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
              <li class="nav-item mx-md-2">
                  <a href="<?php echo e(url('register')); ?>" class="nav-link">Register</a>
              </li>
          </ul>


          <?php if(auth()->guard()->guest()): ?>
      <!-- Mobile Button -->
      <form class="form-inline d-sm-block d-md-none">
        <button class="btn btn-login my-2 my-sm-0" type="button"
                onclick="event.preventDefault(); location.href='<?php echo e(url('login')); ?>';">
          Masuk
        </button>
      </form>

      <!-- Desktop Button -->
      <form class="form-inline my-2 my-lg-0 d-none d-md-block">
        <button class="btn btn-login btn-navbar-right my-2 my-sm-0 px-4" type="button"
                onclick="event.preventDefault(); location.href='<?php echo e(url('login')); ?>';">
          Masuk
        </button>
      </form>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
    <!-- Mobile Button -->
        <form class="form-inline d-sm-block d-md-none" action="<?php echo e(url('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button class="btn btn-login my-2 my-sm-0" type="submit">
                Keluar
            </button>
        </form>

        <!-- Desktop Button -->
        <form class="form-inline my-2 my-lg-0 d-none d-md-block" action="<?php echo e(url('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button class="btn btn-login btn-navbar-right my-2 my-sm-0 px-4" type="submit">
                Keluar
            </button>
        </form>
    <?php endif; ?>
        </div>
      </nav>
    </div>
    <?php /**PATH G:\Tugas Akhir\resources\views/livewire/navbar.blade.php ENDPATH**/ ?>